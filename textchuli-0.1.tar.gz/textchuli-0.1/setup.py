from setuptools import setup, find_packages

setup(
    name="textchuli",
    version="0.1",
    packages=find_packages(),
    install_requires=[
'nltk== 3.8.1',
'pyttsx3==2.90',
'matplotlib==3.8.2',
'jieba==0.42.1',
'gtts==2.5.0'
],
)
